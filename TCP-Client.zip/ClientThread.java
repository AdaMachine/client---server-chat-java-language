package Gui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

/**
*
* @author ���
* @version 1.0 Build in 2018 Nov 20, 2018 
*/

public class ClientThread extends Thread {
	
	// If the client is connect and wait for details from server
	public static boolean connectionFlag = false;
	
	// defina a String var, for user send command from Gui(Client.class/java).
	protected String clientSendLine = null;
	
	// Define by the user when the thread create.
	String address;
	String name;
	
    Socket s1=null;
    String line=null;
    BufferedReader br=null;
    BufferedReader is=null;
    PrintWriter os=null;
    
    /*
     * Constractor for ClientThread
     * @param
     */
    public ClientThread(String name, String address) {
    	
    	this.address = address;
		this.name = name;
		
		try {
	        s1=new Socket(address, 6789); // You can use static final constant PORT_NUM
	        br= new BufferedReader(new InputStreamReader(System.in));
	        is=new BufferedReader(new InputStreamReader(s1.getInputStream()));
	        os= new PrintWriter(s1.getOutputStream());
	        
	        os.println("<connect><" + name + ">");
	        os.flush();
	        
	        connectionFlag = true;
	    }
	    catch (Exception e){
	    	System.out.println("Connection error, make sure the server is runing!");
	    }
    	
    }
    
    /* Function send <disconnect> to the server
     * @param
     */
    public void Disconnect() {
    	clientSendLine = "<disconnect>";
    	Client.setCommand("<system> Disconnected");
    }
    
    
    /* Function to send a message by name or to all.
     * @param
     */
    public void sendMsg(String name, String msg) {
    	
    	if ( name.isEmpty() || name.equals("all") || name.equals("ALL") || name.equals("0") ) {
    		clientSendLine = "<set_msg_all><" + msg + ">";
    	} else {
    		clientSendLine = "<set_msg><" + name + "><" + msg + ">";
    	}
    	
    }
	
    /* Function send a request to the server to get a response with all names of users is connects.
     * @param
     */
    public void getUsers() {
    	clientSendLine = "<users_get>";
    }
    
    /*
     * run function for Thread, when you make a start Thread is well run
     * @see java.lang.Thread#run()
     */
    public void run() {
    	
    	String response = "";
    	
    	try {
    		while ( connectionFlag ) {
    			
    			if (clientSendLine == null)
    				clientSendLine = "<update>";
    			
    			// Send the request command.
    			os.println(clientSendLine);
    			os.flush();
    			
    			// If the Disconnect is send make sure is break and connectionFlag=false;
    			if ( clientSendLine.contains("<disconnect>") ) {
    				connectionFlag=false;
    				break;
    			}
    				
    			
    			clientSendLine = null;
    			
    			response = is.readLine();
				if ( response != null && !response.contains("<none>") )
					Client.setCommand(response);
				
				response="";
				
    			TimeUnit.SECONDS.sleep(2);
    			
    		}
    	} catch (IOException e) {
    		e.printStackTrace();
    		System.out.println("Error: " + e.toString());
    		
    	} catch ( Exception e ) {
    		e.printStackTrace();
    		System.out.println("nONE Error");
    	}
    	
    }
    
    
}
