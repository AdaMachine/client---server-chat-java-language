package Gui;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

/**
*
* @author ���
* @version 1.0 Build in 2018 Nov 20, 2018 
*/

public class ClientThread extends Thread {

	protected int ID;
	protected String name;
	
	protected Socket socket;
	protected InputStream inp;
	protected BufferedReader brinp;
	protected DataOutputStream out;
	protected String outputToClient = "";
	
	protected boolean ClientRun = false;
	
	/* Build(����) Define the socket(get from server) and the ID(index of clientsList from ServerThread)
	 * @param
	 */
	public ClientThread(Socket clientSocket, int index) {
        this.socket = clientSocket;
        this.ID = index;
    }
	
	/* Getting the name of this ClientThread.
	 * @return
	 */
	public String getStringName() {
		return this.name;
	}
	
	/* Function to check if the string we put in the function(Example: checkName("boaz") ) equals to this ClientThread.name and return false or true
	 * @return
	 */
	public boolean checkName(String name_check) {
		if ( this.name.equals(name_check) ) {
			return true;
		}
		return false;
	}
	
	/* Function to set outputToClient var
	 * @param
	 */
	public void setOutput(String text) {
		this.outputToClient = text;
	}
	
	/*
	 * Functions to stop A client Thread and make the client out of clientList(Using function in class ServerThread call clientQuit
	 * @param
	 */
	public void stopClient() {
		Server.setCommand("client " + this.name + " leaved" );
		Server.serverThread.clientQuit(ID);
		ClientRun = false;
		
		// Sending client entered to every client
		for ( int j=0; j<Server.serverThread.clientList.size(); j++ ) {
			if ( Server.serverThread.clientList.get(j) != null )
				Server.serverThread.clientList.get(j).setOutput("<server> client " + this.name + " leaved");
		} 
		
	}
	
	/* run function for this thread.
	 * @see java.lang.Thread#run()
	 */
	public void run() {
		
		// Define the vars
		inp = null;
        brinp = null;
        out = null;
		
        
        // Define the vars inp(getInputStream), brinp(BufferedReader), out(DataOutputStream)
        try {
            inp = socket.getInputStream();
            brinp = new BufferedReader(new InputStreamReader(inp));
            out = new DataOutputStream(socket.getOutputStream());
            
            // Make sure only if the try not crash intil here, allow the while to run;
            ClientRun = true;
        } catch (IOException e) {
        	// The return Make sure to stop the function if is crash
            return;
        }
        
        String clientSendLine;
        String output="";
        
        while ( ClientRun ) {
        	try {
        		
        		// Geting the command thed send from the client
        		clientSendLine = brinp.readLine();
        		
        		// Order the command, split by <?>;
        		String[] splitClientSendLine = clientSendLine.split(">", 0);
        		for (int i=0; i<splitClientSendLine.length; i++) {
        			splitClientSendLine[i] = splitClientSendLine[i].substring(1);
        			//Server.setCommand(splitClientSendLine[i]);
        		}
        		
        		if ((clientSendLine == null) || splitClientSendLine[0].equals("disconnect") ) {
        			stopClient();
        			return;
        		} else if ( splitClientSendLine[0].contains("update") ) {
        			output = outputToClient;
        			outputToClient = "";
        		} else if ( splitClientSendLine[0].contains("set_msg_all") ) {
        			
        			// Check evrey client
        			for ( int i=0; i<Server.serverThread.clientList.size(); i++ ) {
        				if ( Server.serverThread.clientList.get(i) != null && !Server.serverThread.clientList.get(i).getStringName().equals(this.name) ) {
        					// Send a output(message) to client;
        					Server.serverThread.clientList.get(i).setOutput(splitClientSendLine[1]);
        				}
        			}
        			
        			output = "The message send to all of the users!";
        			
        			
        		} else if ( splitClientSendLine[0].contains("set_msg") ) {
        			
        			// Equels to false, if the client found, change to true;
        			boolean messageSendFlag = false;
        			
        			// Check evrey client
        			for ( int i=0; i<Server.serverThread.clientList.size(); i++ ) {
        				// If this client is equels to the name this client wont to send a message
        				if ( Server.serverThread.clientList.get(i) != null && ServerThread.clientList.get(i).checkName(splitClientSendLine[1]) ) {
        					// Add the message to the client output;
        					Server.serverThread.clientList.get(i).setOutput(splitClientSendLine[2]);
        					messageSendFlag = true;
        				}
        			}
        			
        			if (messageSendFlag) {
        				output = "Message send!";
        			} else {
        				output = "User not found!";
        			}
        			
        		} else if ( splitClientSendLine[0].contains("users_get") ) {
        			
        			// Check evrey client
        			for ( int i=0; i<Server.serverThread.clientList.size(); i++ ) {
        				
        				if ( Server.serverThread.clientList.get(i) != null ) {
        					
        					if ( output == "" ) {
        						output = Server.serverThread.clientList.get(i).getStringName();
        					} else {
        						output += ", " + Server.serverThread.clientList.get(i).getStringName();
        					}
        					
        				}
        				
        			}
        			
        		} else if ( splitClientSendLine[0].contains("connect") ) {
        			
        			boolean userCreateFlag = true;
        			
        			// Check evrey client
        			/*for ( int i=0; i<Server.serverThread.clientList.size(); i++ ) {
        				
        				// Check if client have the same name
        				if ( Server.serverThread.clientList.get(i) != null ) {
        					if ( Server.serverThread.clientList.get(i).checkName(splitClientSendLine[1]) == true ) {
        						//output = "The name you choose all redy connect! Try to connect with anyorder name.";
            					//stopClient();
        						userCreateFlag = false;
        					}
        				}
        				
        			}*/
        			
        			if ( userCreateFlag ) {
        				// The client send a connect and name;
            			this.name = splitClientSendLine[1];
            			// Send a output welcome to the client
            			output = "Welcome to the server!";
            			// Add a line with a msg to server
            			Server.setCommand("client " + splitClientSendLine[1] + " entered" );
            			
            			// Sending client entered to every client
            			for ( int j=0; j<Server.serverThread.clientList.size(); j++ ) {
            				if ( Server.serverThread.clientList.get(j) != null )
            					Server.serverThread.clientList.get(j).setOutput("<server> client " + this.name + " entered");
            			} 
            			
        			} else {
        				output = "The name you choose all redy connect! Try to connect with anyorder name.";
        				
        				stopClient();
        			}
        			
        			
        			
        			
        		}
        		
        		
        		// Make sure every request get an answer even if the outout is empty.
        		if ( output.isEmpty() )
        			output = "<none>";
        		out.writeBytes(output + "\n");
                out.flush();
                
                output = "";
        		
        	} catch (Exception e) {
        		stopClient();
                return;
            }
        }
        
	}
	
}
