package Gui;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/**
*
* @author ���
* @version 1.0 Build in 2018 Nov 20, 2018 
*/

public class ServerThread extends Thread {

		// Choose what port the server is going to play(work on)...
		final static int PORT = 6789;
		
		// List of all clients Thread (every client have a clientThread in this list)
		public static java.util.List<ClientThread> clientList = new ArrayList<ClientThread>();
		
		// var ServerSocket and Socket, make sure is have access from all of this class only(using protected)
		protected ServerSocket serverSocket = null;
	    protected  Socket socket = null;
	    
	    // Defian if the while need to be run
	    protected static boolean ServerRun = false;
	    
	    /*
	     * Function run for this Thread
	     * @see java.lang.Thread#run()
	     */
	    public void run() {
	    	//creats serversocket and contains him����
	    	
	    	// Define the serverSocket;
	    	try {
	    		// Create the socketServer with port var(defain in the head of this code)
	            serverSocket = new ServerSocket(PORT);
	            
	            // Make sure thed if the Thread create the while will run
		    	ServerRun = true;
	        } catch (IOException e) {
	            //e.printStackTrace();
	        	Server.setCommand("Server crash!");
	        	return;
	        }
	    	
	    	
	    	while (ServerRun) {
	    		
	    		try {
	                socket = serverSocket.accept();
	                ClientThread a = new ClientThread(socket, clientList.size());
		            a.start();
		            //Server.setCommand("new Client id "+clientList.size());
		            clientList.add(a);
	            } catch (IOException e) {
	                //Server.setCommand("");
	            }
	    		
	    	}
	    }
	    
	    /*
	     * Function for stoping the Server Thread(this ServerThread) and colsing the serverSocker;
	     * @param
	     */
	    public void stopServer() {
	    	
	    	ServerRun = false;
	    	
	    	try {
	    		// Closing now the socket!
	    		serverSocket.close();
	    	} catch (Exception e) {
                Server.setCommand("try to close socket but crash, close this application and open again!");
            }
	    	
	    	
	    	
	    	clientList = null;
	    }
	    
	    /*
	     * Function clientQuit, remove the clientThread from clientList and make it null insted.
	     * @param
	     */
	    public static void clientQuit(int index) {
			//Server.setCommand("Client " + index + " exit right now!");
			//System.out.println("Client " + index + " exit right now!");
			clientList.set(index, null);
		}
	
}
