package Gui;

import static org.junit.jupiter.api.Assertions.*;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

class TCPServer_test {
	
	@Test
	void Servertest() throws IOException {
		ServerSocket server1=new ServerSocket(1234);
		assertTrue(server1.getLocalPort()==1234);
		assertEquals(InetAddress.getLocalHost().getHostAddress(), "192.168.56.1");
	}

}
